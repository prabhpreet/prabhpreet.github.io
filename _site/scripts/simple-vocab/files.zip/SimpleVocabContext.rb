require 'green_shoes'
require 'open-uri'
require 'json'
require 'HTMLEntities'
require 'nokogiri'
require 'mechanize'
require 'launchy'

$word = "debauchery"
$vocab = []
$vocab_intuitive = {}
$mechanic = Mechanize.new

$articles  = Array.new

$convert_text = HTMLEntities.new
	

$counter = 0

$open_url = Proc.new {
	begin
		Launchy.open($articles[$counter]["url"])
	rescue
		puts "Couldn't launch url"
		p $articles[$counter]["url"]
	end
}

$query = ""

Shoes.app(title: "SimpleVocab Search") do

	def letter?(character)
		character =~ /[A-Za-z]/
	end
	
	
	stack(margin:20) do
		
		@q = title($query,
			  font:   "Trebuchet MS",
			  stroke: red,
			  align: "center")
			  
		@l = para("Type, press enter", :align=>"center")
		
		button("This word eludes me. Please elaborate!",
			  font:   "Trebuchet MS",
			  stroke: white,
			  align: "center",
			  width: '100%',
			 ) do
			 window(title:"Definition:" + $word) do
				
				@vocab_stack = 	stack(margin:20) do	
								if !$vocab_intuitive.empty?
				para(strong($vocab_intuitive["definition"]),:font=> "Georgia")
			
				para($vocab_intuitive["example"],:font=> "Georgia")
			end
				
			if !$vocab.empty?
				$vocab.each do |term|
					para(strong(term["type"]) + ": " + term ["definition"],:font=> "Georgia")
				end
			end
				end
			 end
		end
	end
	
	
	
	
	def define
		
		$vocab = []
		$vocab_intuitive = {}
		vocab_page = $mechanic.get("http://www.vocabulary.com/dictionary/"+ $word)


		if vocab_page.at('p.short') != nil
			$vocab_intuitive = {"definition"=> vocab_page.at('p.short').text.strip, "example"=> vocab_page.at('p.long').text.strip}

			vocab_page.search('div.group div.ordinal h3.definition').each do |term|
				term = term.text.delete("\r\n\t")
				$vocab.push({"type"=> term.split()[0], "definition"=> term.split(' ')[1..-1].join(' ')})
				
			end
		else
			begin
				suggestion = vocab_page.at('div#results ol.suggestions').text.split()[0]
				$word = suggestion
				$query = suggestion
				@l.text = suggestion
				vocab_page = $mechanic.get("http://www.vocabulary.com/dictionary/"+ suggestion)
				if vocab_page.at('p.short') != nil
					$vocab_intuitive = {"definition"=> vocab_page.at('p.short').text.strip, "example"=> vocab_page.at('p.long').text.strip}

					vocab_page.search('div.group div.ordinal h3.definition').each do |term|
						term = term.text.delete("\r\n\t")
						$vocab.push({"type"=> term.split()[0], "definition"=> term.split(' ')[1..-1].join(' ')})
						
					end
				end
			rescue
				wordnik_json = JSON.parse(open("http://api.wordnik.com:80/v4/word.json/"+ $word +"/definitions?limit=3&includeRelated=true&sourceDictionaries=all&useCanonical=true&includeTags=false&api_key=a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5").read)
				
				wordnik_json.each do |term|
					$vocab.push({"type"=>term["partOfSpeech"], "definition"=>term["text"]})
				end
				
				
			end
			
		end

		
		
		guardian_json = JSON.parse(open("http://content.guardianapis.com/search?order-by=newest&show-fields=shortUrl%2Cbody%2Cheadline&page=1&page-size=3&q="+ $word + "&api-key=4vrvcthpjjddad3ekq8tc3x2").read)

		guardian_articles = guardian_json["response"]["results"].take(3)

		nyt_json = JSON.parse(open("http://api.nytimes.com/svc/search/v2/articlesearch.json?q="+ $word + "&fq=body%3A%28%22"+ $word +"%22%29&sort=newest&fl=web_url%2Cheadline&hl=true&api-key=a8034ba4619f6d2cd9dd38f73414dbed:18:71827361").read)

		nyt_articles = nyt_json["response"]["docs"].take(3)

		
		$articles = []
		$counter = 0
		
		guardian_articles.each do |article|
			article = article["fields"]
			headline = $convert_text.encode($convert_text.decode(article["headline"]))
			url = article["shortUrl"].delete('\\')
			
			xml = Nokogiri::XML("<root>" + article["body"] + "</root>")
			
			xml.css("a").remove
			xml.css("b").remove
			
			content = xml.text
			content = content.scan(/(?:\. ?)?(\S.*?(?:\.|$))/)
			str = []
			content.each do |r|
				r.each do |s|
					if s.match($word)
						str.push(s.split($word))
					end
				end
			end
			
			
			content = str
			str = []
			
			
			
			content.each do |r|
				r.each do |s|
					str.push($convert_text.encode(s))
					if s != r.last
						str.push(strong($word))
					end
				end
				if r != content.last
					str.push("...")
				end
			end
			
			
			$articles.push({"headline"=>headline,
				"content"=>str,
				"source" => "Guardian",
				"url" =>url
			})
			
		end
		
		nyt_articles.each do |article|
			headline = $convert_text.encode($convert_text.decode(article["headline"]["main"]))
			content = article["snippet"].split(/\<strong>.*<\/strong>/)
			url = article["web_url"].delete('\\')
			str = []
			content.each do |s|
				str.push($convert_text.encode(s))
				if s != content.last
					str.push(strong($word))
				end
			end
			$articles.push({"headline"=>headline,
				"content"=>str, 
				"source" => "NYT",
				"url" => url
			})	
		end
		
		updateArticles
		@l.text = "Escape to empty"
	end
	keypress do |k|
		if k == "Left"
			if $counter == 0
				$counter = $articles.count - 1
			else
				$counter = $counter - 1
			end
			
			updateArticles
			
		elsif k == "Right"
			$counter = $counter + 1
			if $counter == $articles.count
				$counter = 0
			end
			
			updateArticles
		elsif k == "\n"
			@l.text = "Loading"
			$word = $query
			define
		elsif k == "BackSpace"
			$query = $query[0..-2]
		elsif k == "Escape"
			$query = ""
		elsif letter?(k)
			$query = $query + k
		end
		@q.text = $query
	end
	
	def updateArticles
		@news_container.clear do
			if !$articles.empty?
				
				title($articles[$counter]["headline"], :font =>"Georgia")
				para ($articles[$counter]["content"].join("")), :font=>"Georgia"
				para(link("-" + $articles[$counter]["source"], &$open_url), :font=>"Georgia", :align=>"right")
			end
		end		
	end
	
	
	
	@news_container = stack(margin:10) do
		if !$articles.empty?
			
			$articles = $articles.shuffle
			title($articles[$counter]["headline"], :font =>"Georgia")
			para ($articles[$counter]["content"].join("")), :font=>"Georgia"
			para(link("-" + $articles[$counter]["source"], &$open_url), :font=>"Georgia", :align=>"right")
		end	
	end
	every(30) do

			$counter = $counter + 1
			if $counter == $articles.count
				$counter = 0
			end
			updateArticles
	end

	
end